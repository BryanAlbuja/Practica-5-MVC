#include <iostream>
#include "vista.h"

#include <string>

using namespace std;


int main()
{

    cout << "\n \t \t {***UNIVERSIDAD POLITECNICA SALESIANA***}" << endl;
    cout << "\t \t \t [Autor:Pedro Vinicio Alajo]" << endl;
    cout << " \t \n [Ejemplo MVC]" << endl;
    Vista v;
    v.imprimir();
    v.actualizaNota();
    v.imprimir();
    v.ay();
    v.imprimir();
    return 0;
}
